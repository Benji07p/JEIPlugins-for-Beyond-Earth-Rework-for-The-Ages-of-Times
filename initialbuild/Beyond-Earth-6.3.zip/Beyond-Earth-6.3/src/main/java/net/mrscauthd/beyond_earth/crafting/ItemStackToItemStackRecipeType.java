package net.mrscauthd.beyond_earth.crafting;

public class ItemStackToItemStackRecipeType<T extends ItemStackToItemStackRecipe> extends BeyondEarthRecipeType<T> {

	public ItemStackToItemStackRecipeType(String name) {
		super(name);
	}

}
