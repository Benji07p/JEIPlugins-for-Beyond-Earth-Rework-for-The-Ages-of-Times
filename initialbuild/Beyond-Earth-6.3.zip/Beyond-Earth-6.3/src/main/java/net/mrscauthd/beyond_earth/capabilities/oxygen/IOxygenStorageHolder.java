package net.mrscauthd.beyond_earth.capabilities.oxygen;

public interface IOxygenStorageHolder {
	void onOxygenChanged(IOxygenStorage oxygenStorage, int oxygenDelta);
}
