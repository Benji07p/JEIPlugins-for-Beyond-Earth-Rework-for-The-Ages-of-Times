package net.mrscauthd.beyond_earth.events;

import net.minecraft.world.entity.player.Player;

public class JetSuitMovement {

    public static void movement(Player player) {
        if (!player.isPassenger()) {
            //System.out.println(player.isShiftKeyDown());
        }
    }
}
