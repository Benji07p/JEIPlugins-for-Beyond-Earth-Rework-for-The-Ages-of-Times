package net.mrscauthd.beyond_earth.gauge;

import java.util.List;

public interface IGaugeValuesProvider {

	public List<IGaugeValue> getDisplayGaugeValues();
}
